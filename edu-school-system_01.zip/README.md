# EduTrack — School Attendance & Examination Management System

A full-stack Node.js school management system built with **Express.js**, **Pug**, **Sequelize ORM**, and **MySQL2**.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Server | Express.js |
| Views | Pug (Jade) |
| ORM | Sequelize |
| Database | MySQL (via mysql2) |
| Auth | express-session + bcryptjs |
| Flash | express-flash |

---

## Prerequisites

- Node.js 18+
- MySQL 8.0+ running locally

---

## Setup

### 1. Extract & install
```bash
tar -xzf edutrack-school-system.tar.gz
cd school-system
npm install
```

### 2. Create MySQL database
```sql
CREATE DATABASE school_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 3. Configure `.env`
```
DB_HOST=localhost
DB_USER=root
DB_PASS=your_mysql_password
DB_NAME=school_system
SESSION_SECRET=change_this_secret
PORT=3000
```

### 4. Seed the database (creates admin + Tanzania public holidays)
```bash
npm run seed
```

### 5. Start the server
```bash
npm start
```

Open: http://localhost:3000

---

## Default Credentials

| Role | URL | Username/Email | Password |
|------|-----|----------------|----------|
| Admin | /auth/admin/login | `admin` | `admin123` |
| Teacher | /auth/teacher/login | (their email) | PhoneNumber + DeptCode (e.g. `0712345678EYC`) |

---

## Features

### Admin Panel
- **Dashboard** — Total students, teachers, classes, departments; recent attendance; quick setup actions
- **Departments** — Add EYC, Primary, Secondary departments
- **Teachers** — Add teachers (auto-generates password from phone + dept code); assign/revoke roles (Teacher, Class Teacher, Head of Dept, Admin); activate/deactivate
- **Classes** — Create classes linked to departments
- **Streams** — Create streams (A, B, East, West…) linked to classes
- **Subjects** — Create subjects linked to classes
- **Students** — Enroll students with admission number, gender, DOB, class, stream
- **Assignments**
  - Assign teachers to one or more classes
  - Assign subjects to classes
  - Assign teachers to teach subjects in specific classes
- **Public Holidays** — Add/remove holidays (pre-seeded with Tanzania holidays)
- **Reports**
  - Attendance report per class with per-student summary and % attendance
  - Examination marks report per class with all subject scores

### Teacher Portal
- **Login** with email + password
- **Dashboard** — Shows assigned classes, recent attendance, weekend/holiday warning
- **Attendance Taking**
  - Date is auto-set to today (read-only — cannot be changed)
  - Weekends (Sat/Sun) are automatically blocked
  - Public holidays are automatically blocked
  - Mark each student: **Present / Absent / Sick**
  - Saves existing attendance if re-opened (shows saved status)
- **Attendance History** — Browse past attendance by class and date
- **Enter Marks** — Per subject per class per term:
  - Components: H/W, G/W, QZ, C/W, U/T, F/E (all out of 100)
  - **Weighted**: 5%H/W + 10%G/W + 15%QZ + 15%C/W + 25%U/T + 30%F/E
  - **Unweighted**: Average of all 6
  - Live calculation as you type — no need to submit to see total/grade
  - Per-student method selection
- **Report Cards** — Printable student report card with all subjects, grades, attendance summary, signature lines

### Grading Scale
| Grade | Range | Remark |
|-------|-------|--------|
| A | 80–100 | Excellent |
| B | 70–79 | Very Good |
| C | 60–69 | Good |
| D | 50–59 | Satisfactory |
| F | 0–49 | Fail |

---

## Project Structure

```
school-system/
├── app.js                    # Express entry point
├── seed.js                   # DB seeder (admin + holidays)
├── config/
│   └── database.js           # Sequelize connection
├── middleware/
│   └── auth.js               # requireAdmin / requireTeacher guards
├── models/
│   └── index.js              # All Sequelize models + associations
├── routes/
│   ├── auth.js               # Login / logout routes
│   ├── admin.js              # All admin CRUD routes
│   └── teacher.js            # Attendance + marks routes
├── utils/
│   └── grading.js            # calculateScore, getGrade, getRemark
├── public/
│   ├── css/style.css
│   └── js/app.js
└── views/
    ├── layout.pug
    ├── index.pug
    ├── auth/
    │   ├── admin-login.pug
    │   └── teacher-login.pug
    ├── partials/
    │   ├── admin-layout.pug
    │   └── teacher-layout.pug
    ├── admin/                # 11 admin views
    └── teacher/              # 6 teacher views
```

---

## Database Models

- `Department` — EYC / Primary / Secondary
- `Teacher` — with role, department link
- `Admin` — system admin
- `Class` — linked to department
- `Stream` — linked to class
- `Subject` — linked to class
- `Student` — linked to class + stream
- `TeacherClass` — M:N teacher ↔ class
- `TeacherSubject` — M:N teacher ↔ subject (per class)
- `ClassSubject` — M:N class ↔ subject
- `PublicHoliday` — dates excluded from attendance
- `Attendance` — per student per class per date (unique)
- `Mark` — per student per subject per class per term/year (unique)
