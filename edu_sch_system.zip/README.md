# School Management System

A web-based school administration system for managing academic years, classes, teachers, students, attendance, examinations, reports, discipline, lesson plans, and timetables.

The application is built with Node.js, Express, Pug, Sequelize, and MySQL. It provides separate authenticated experiences for administrators, teachers, and academic staff.

## Features

### Administration

- Dashboard with school statistics and operational summaries
- Academic years and terms
- Departments, classes, streams, and subjects
- Teacher accounts, roles, activation, and class/subject assignments
- Student enrollment, editing, import, transfers, graduation, and status tracking
- Attendance and examination reports
- Report cards and printable progressive/final reports
- Public holidays
- Database backup management

### Teacher portal

- Teacher dashboard for assigned classes and subjects
- Daily attendance for present, absent, and sick students
- Attendance history and printable attendance sheets
- Examination mark entry and editing
- Weighted and unweighted grading
- Academic reports, exam analysis, progressive reports, and report cards
- Student comments
- Lesson plan creation, review, feedback, approval, and hand-over
- Personal timetable management and substitute-teacher requests
- Discipline records

### Academic and platform services

- Academician view of teacher profiles and lists
- Role-based session authentication
- Password hashing with `bcryptjs`
- Teacher password change and password-reset email flows
- Automatic Sequelize session storage
- Weekly database backup scheduling (Sunday at 02:00 in `Africa/Dar_es_Salaam`)
- Optional SMTP email delivery
- Optional Anthropic-powered comment generation

## Technology

| Area | Technology |
| --- | --- |
| Runtime | Node.js |
| Web framework | Express 5 |
| Templates | Pug |
| ORM | Sequelize |
| Database | MySQL |
| Sessions | `express-session` with Sequelize session store |
| Authentication | `bcryptjs` |
| Uploads | `multer` |
| Scheduling | `node-cron` |
| Email | `nodemailer` |

## Requirements

- Node.js 18 or newer
- npm
- MySQL 8 or a compatible MySQL server
- `mysqldump` available on the server if database backups are required

## Installation

From the project directory:

```bash
npm install
```

Create the database before starting the application:

```sql
CREATE DATABASE sch_system
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
```

The database name above matches the default in `config/database.js`. You can use another name by setting `DB_NAME` in `.env`.

## Configuration

Create a `.env` file in the project root. Do not commit this file.

```dotenv
DB_HOST=localhost
DB_USER=root
DB_PASS=your_mysql_password
DB_NAME=sch_system
SESSION_SECRET=replace-with-a-long-random-secret
PORT=3000
APP_URL=http://localhost:3000
```

### Optional email configuration

Email is used for teacher password-reset messages and can also be used for backup notifications.

```dotenv
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SM_US=your-smtp-user
SM_PA=your-smtp-password-or-app-password

# Backup mail settings. MAIL_* is used by the backup utility.
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USER=your-backup-mail-user
MAIL_PASS=your-backup-mail-password
MAIL_FROM=School Management System <noreply@example.com>
BACKUP_EMAIL=backup-recipient@example.com
BACKUP_DIR=./backups
```

Use an SMTP app password where the provider requires one. Never place API keys, passwords, or tokens in source control.

### Optional AI comment generation

The teacher comment-generation endpoint reads:

```dotenv
ANTHROPIC_API_KEY=your-anthropic-api-key
```

If this variable is not configured, the rest of the application remains available, but AI-assisted comment generation cannot be used.

## Starting the application

Start the production-style Node process:

```bash
npm start
```

The current `dev` script starts the same application process:

```bash
npm run dev
```

Open `http://localhost:3000` (or the configured `PORT`). The application authenticates against MySQL and synchronizes the Sequelize models on startup.

Login pages:

- Admin: `/auth/admin/login`
- Teacher: `/auth/teacher/login`

The root page redirects authenticated users to their relevant dashboard.

## Database initialization and migrations

On startup, `app.js` runs `sequelize.sync({ alter: true })` and creates the session table. This is convenient for the current deployment but should be reviewed carefully before using automatic schema alteration in production.

The repository also contains numbered SQL migrations in `utils/`. Run them with:

```bash
npm run migrate
```

The migration runner executes every file matching `utils/NNN*.sql` in sorted order. The current migration creates the `timetables` table. Run migrations only after configuring the target database.

## Seeders

Seeders are standalone scripts; there is currently no `npm run seed` script.

Create the default administrator account:

```bash
node seeders/admin_seeder.js
```

Seed the included Tanzania public holidays:

```bash
node seeders/holiday_seeder.js
```

Both scripts synchronize the models before inserting data and use `findOrCreate`/existence checks where applicable. Change or rotate any initial credentials immediately after first login.

## Project structure

```text
.
├── app.js                       # Express application and startup
├── package.json                # Scripts and dependencies
├── config/
│   └── database.js             # Sequelize/MySQL connection
├── middleware/
│   └── auth.js                 # Admin and teacher authorization middleware
├── models/
│   └── index.js                # Models, associations, and exports
├── routes/
│   ├── auth.js                 # Login, logout, and password flows
│   ├── admin.js                # Administration and reporting routes
│   ├── teacher.js              # Teacher portal routes
│   ├── academician.js          # Academic staff routes
│   ├── lessonPlans.js          # Lesson plan workflows
│   └── discipline.js           # Discipline workflows
├── seeders/
│   ├── admin_seeder.js         # Default administrator seeder
│   └── holiday_seeder.js       # Public holiday seeder
├── utils/
│   ├── 001-create-timetables.sql
│   ├── run-migrations.js       # Numbered SQL migration runner
│   ├── grading.js              # Score and grade calculations
│   ├── csvImport.js            # Student/result import helpers
│   ├── backup.js               # mysqldump, zip, email, and pruning
│   ├── mailer.js               # Teacher password-reset mail
│   └── scheduler.js            # Weekly backup scheduler
├── public/
│   ├── css/style.css
│   └── images/                 # School branding assets
├── views/                     # Pug templates by portal and feature
├── uploads/                   # Uploaded/imported files
└── backups/                   # Runtime backup output when enabled
```

## Main data models

The model layer includes:

- `Admin`, `Teacher`, and `Department`
- `AcademicYear` and `Term`
- `Class`, `Stream`, `Subject`, and their assignment tables
- `Student`
- `Attendance` and `Mark`
- `ReportComment`
- `DisciplineReason` and `DisciplineRecord`
- `Timetable` and `SubstituteRequest`
- `LessonPlan` and `LessonPlanFeedback`
- `PublicHoliday`

Associations and database table names are defined in `models/index.js`.

## Backups

The scheduler starts with the web application and runs every Sunday at 02:00 using the `Africa/Dar_es_Salaam` timezone. A backup:

1. Runs `mysqldump` for `DB_NAME`
2. Compresses the SQL dump into a ZIP file
3. Emails the ZIP to `BACKUP_EMAIL` or `MAIL_USER`
4. Retains the four newest ZIP files

Backups can also be triggered from the administrator backup interface. Ensure `mysqldump` is installed and available in the process environment, and configure the mail variables before enabling operational backups.

## Development notes

- There is no automated test suite or lint script currently defined in `package.json`.
- Keep `.env`, `backups/`, and uploaded files out of version control.
- Use the existing route authorization middleware when adding protected routes.
- Prefer model associations and Sequelize queries over duplicated SQL.
- Validate imports and uploaded files before processing them.
- Review `sequelize.sync({ alter: true })` before deploying to a production database.

## Troubleshooting

### Database connection fails

Verify that MySQL is running, the configured database exists, and `DB_HOST`, `DB_USER`, `DB_PASS`, and `DB_NAME` match the server.

### Port already in use

Set another port in `.env`:

```dotenv
PORT=3001
```

### Password reset email does not arrive

Check `SMTP_HOST`, `SMTP_PORT`, `SM_US`, and `SM_PA`, confirm that the SMTP provider permits the credentials, and set `APP_URL` to the URL users can reach.

### Backups fail

Confirm that `mysqldump` can be run by the account starting Node.js, the database credentials are valid, `BACKUP_DIR` is writable, and the backup mail settings are configured.

## License

The project currently uses the `ISC` license value declared in `package.json`.
