// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function () {
  const themeToggle = document.querySelector('.theme-toggle');
  const savedTheme = localStorage.getItem('cams-theme') || 'light';
  document.documentElement.dataset.theme = savedTheme;
  if (themeToggle) {
    themeToggle.querySelector('i').className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    themeToggle.addEventListener('click', function () {
      const nextTheme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = nextTheme;
      localStorage.setItem('cams-theme', nextTheme);
      themeToggle.querySelector('i').className = nextTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    });
  }
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity .5s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 5000);
  });

  const navToggle = document.querySelector('.nav-toggle');
  const sidebar = document.querySelector('.sidebar');

  if (navToggle && sidebar) {
    const closeSidebar = () => {
      sidebar.classList.remove('is-open');
      document.body.classList.remove('sidebar-open');
      navToggle.setAttribute('aria-expanded', 'false');
    };

    const openSidebar = () => {
      sidebar.classList.add('is-open');
      document.body.classList.add('sidebar-open');
      navToggle.setAttribute('aria-expanded', 'true');
    };

    navToggle.addEventListener('click', () => {
      if (window.innerWidth <= 700) {
        const isOpen = sidebar.classList.contains('is-open');
        if (isOpen) closeSidebar();
        else openSidebar();
        return;
      }
      const isCollapsed = sidebar.classList.toggle('is-collapsed');
      document.body.classList.toggle('sidebar-collapsed', isCollapsed);
      navToggle.setAttribute('aria-expanded', String(!isCollapsed));
    });

    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        if (window.innerWidth <= 700) closeSidebar();
      });
    });

    document.addEventListener('click', (event) => {
      if (window.innerWidth > 700) return;
      const clickedInsideSidebar = sidebar.contains(event.target);
      const clickedToggle = navToggle.contains(event.target);
      if (!clickedInsideSidebar && !clickedToggle && sidebar.classList.contains('is-open')) {
        closeSidebar();
      }
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && sidebar.classList.contains('is-open')) {
        closeSidebar();
      }
    });
  }

  // Confirm before delete forms
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', function (e) {
      if (!confirm(this.dataset.confirm)) e.preventDefault();
    });
  });
});
