const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const bcrypt = require("bcryptjs");

// ─── Department ───────────────────────────────────────────────────────────────
const Department = sequelize.define(
  "Department",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(50), allowNull: false, unique: true },
    code: {
      type: DataTypes.ENUM("EYC", "Primary", "Secondary"),
      allowNull: false,
      unique: true,
    },
  },
  { tableName: "departments", timestamps: true },
);

// ─── Teacher ──────────────────────────────────────────────────────────────────
const Teacher = sequelize.define(
  "Teacher",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    fullName: { type: DataTypes.STRING(100), allowNull: false },
    phone: { type: DataTypes.STRING(20), allowNull: false, unique: true },
    email: { type: DataTypes.STRING(100), allowNull: false, unique: true },
    password: { type: DataTypes.STRING(255), allowNull: false },
    role: {
      type: DataTypes.ENUM("teacher", "class_teacher", "academician", "admin"),
      defaultValue: "teacher",
    },
    departmentId: { type: DataTypes.INTEGER, allowNull: false },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    mustChangePassword: { type: DataTypes.BOOLEAN, defaultValue: true },
    resetToken: { type: DataTypes.STRING(255), allowNull: true },
    resetTokenExpiry: { type: DataTypes.DATE, allowNull: true },
    loginAttempts: { type: DataTypes.INTEGER, defaultValue: 0 },
    lockedUntil: { type: DataTypes.DATE, allowNull: true },
  },
  {
    tableName: "teachers",
    timestamps: true,
    instanceMethods: {
      validatePassword: function (password) {
        return bcrypt.compare(password, this.password);
      },
    },
  },
);

// ─── Admin ────────────────────────────────────────────────────────────────────
const Admin = sequelize.define(
  "Admin",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    username: { type: DataTypes.STRING(50), allowNull: false, unique: true },
    password: { type: DataTypes.STRING(255), allowNull: false },
    email: { type: DataTypes.STRING(100) },
    loginAttempts: { type: DataTypes.INTEGER, defaultValue: 0 },
    lockedUntil: { type: DataTypes.DATE, allowNull: true },
  },
  {
    tableName: "admins",
    timestamps: true,
    instanceMethods: {
      validatePassword: function (password) {
        return bcrypt.compare(password, this.password);
      },
    },
  },
);

// ─── Academic Year ─────────────────────────────────────────────────────────────
const AcademicYear = sequelize.define(
  "AcademicYear",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(20), allowNull: false, unique: true },
    startDate: { type: DataTypes.DATEONLY, allowNull: false },
    endDate: { type: DataTypes.DATEONLY, allowNull: false },
    isCurrent: { type: DataTypes.BOOLEAN, defaultValue: false },
  },
  { tableName: "academic_years", timestamps: true },
);

// ─── Term ─────────────────────────────────────────────────────────────────────
const Term = sequelize.define(
  "Term",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    academicYearId: { type: DataTypes.INTEGER, allowNull: false },
    name: {
      type: DataTypes.ENUM("Term 1", "Term 2", "Term 3"),
      allowNull: false,
    },
    startDate: { type: DataTypes.DATEONLY, allowNull: false },
    endDate: { type: DataTypes.DATEONLY, allowNull: false },
    isOpen: { type: DataTypes.BOOLEAN, defaultValue: true },
  },
  { tableName: "terms", timestamps: true },
);

// ─── Class ────────────────────────────────────────────────────────────────────
const Class = sequelize.define(
  "Class",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(50), allowNull: false },
    departmentId: { type: DataTypes.INTEGER, allowNull: false },
  },
  { tableName: "classes", timestamps: true },
);

// ─── Stream ───────────────────────────────────────────────────────────────────
const Stream = sequelize.define(
  "Stream",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(50), allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
  },
  { tableName: "streams", timestamps: true },
);

// ─── Subject ──────────────────────────────────────────────────────────────────
const Subject = sequelize.define(
  "Subject",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(100), allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
  },
  {
    tableName: "subjects",
    timestamps: true,
    indexes: [{ unique: true, fields: ["classId", "name"] }],
  },
);

// ─── Student ──────────────────────────────────────────────────────────────────
const Student = sequelize.define(
  "Student",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    fullName: { type: DataTypes.STRING(100), allowNull: false },
    gender: { type: DataTypes.ENUM("Male", "Female"), allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    streamId: { type: DataTypes.INTEGER },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    status: { type: DataTypes.ENUM("Active", "Moved"), defaultValue: "Active" },
  },
  {
    tableName: "students",
    timestamps: true,
    indexes: [
      { name: "idx_students_class_active", fields: ["classId", "isActive"] },
    ],
  },
);

// ─── Teacher-Class Assignment ─────────────────────────────────────────────────
const TeacherClass = sequelize.define(
  "TeacherClass",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    teacherId: { type: DataTypes.INTEGER, allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    streamId: { type: DataTypes.INTEGER, allowNull: true },
    isClassTeacher: { type: DataTypes.BOOLEAN, defaultValue: false },
  },
  { tableName: "teacher_classes", timestamps: true },
);

// ─── Report Comment ───────────────────────────────────────────────────────────
const ReportComment = sequelize.define(
  "ReportComment",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    studentId: { type: DataTypes.INTEGER, allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    teacherId: { type: DataTypes.INTEGER, allowNull: false },
    term: {
      type: DataTypes.ENUM("Term 1", "Term 2", "Term 3"),
      allowNull: false,
    },
    academicYear: { type: DataTypes.STRING(9), allowNull: false },
    comment: { type: DataTypes.TEXT, allowNull: false },
  },
  {
    tableName: "report_comments",
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ["studentId", "classId", "term", "academicYear"],
      },
    ],
  },
);

// ─── Teacher-Subject Assignment ───────────────────────────────────────────────
const TeacherSubject = sequelize.define(
  "TeacherSubject",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    teacherId: { type: DataTypes.INTEGER, allowNull: false },
    subjectId: { type: DataTypes.INTEGER, allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
  },
  {
    tableName: "teacher_subjects",
    timestamps: true,
    indexes: [{ unique: true, fields: ["teacherId", "classId", "subjectId"] }],
  },
);

// ─── Class-Subject Assignment ─────────────────────────────────────────────────
const ClassSubject = sequelize.define(
  "ClassSubject",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    subjectId: { type: DataTypes.INTEGER, allowNull: false },
  },
  {
    tableName: "class_subjects",
    timestamps: true,
    indexes: [{ unique: true, fields: ["classId", "subjectId"] }],
  },
);

// ─── Public Holiday ───────────────────────────────────────────────────────────
const PublicHoliday = sequelize.define(
  "PublicHoliday",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(100), allowNull: false },
    date: { type: DataTypes.DATEONLY, allowNull: false, unique: true },
  },
  { tableName: "public_holidays", timestamps: true },
);

// ─── Attendance ───────────────────────────────────────────────────────────────
const Attendance = sequelize.define(
  "Attendance",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    studentId: { type: DataTypes.INTEGER, allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    date: { type: DataTypes.DATEONLY, allowNull: false },
    status: {
      type: DataTypes.ENUM("present", "absent", "sick"),
      allowNull: false,
    },
    takenBy: { type: DataTypes.INTEGER, allowNull: false },
  },
  {
    tableName: "attendance",
    timestamps: true,
    indexes: [{ unique: true, fields: ["studentId", "classId", "date"] }],
  },
);

// ─── Marks ────────────────────────────────────────────────────────────────────
const Mark = sequelize.define(
  "Mark",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    studentId: { type: DataTypes.INTEGER, allowNull: false },
    subjectId: { type: DataTypes.INTEGER, allowNull: false },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    term: {
      type: DataTypes.ENUM("Term 1", "Term 2", "Term 3"),
      allowNull: false,
    },
    academicYear: {
      type: DataTypes.STRING(9),
      allowNull: false,
      defaultValue: "2024/2025",
    },
    homework: { type: DataTypes.FLOAT, defaultValue: 0 },
    groupWork: { type: DataTypes.FLOAT, defaultValue: 0 },
    quiz: { type: DataTypes.FLOAT, defaultValue: 0 },
    classWork: { type: DataTypes.FLOAT, defaultValue: 0 },
    unitTest: { type: DataTypes.FLOAT, defaultValue: 0 },
    finalExam: { type: DataTypes.FLOAT, defaultValue: 0 },
    finalExamMax: {
      type: DataTypes.FLOAT,
      defaultValue: null,
      allowNull: true,
    },
    gradingMethod: {
      type: DataTypes.ENUM("weighted", "unweighted"),
      defaultValue: "weighted",
    },
    totalScore: { type: DataTypes.FLOAT },
    grade: { type: DataTypes.STRING(2) },
    enteredBy: { type: DataTypes.INTEGER },
  },
  {
    tableName: "marks",
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ["studentId", "subjectId", "classId", "term", "academicYear"],
      },
    ],
  },
);

// ─── Timetable (Teacher custom timetables) ───────────────────────────────────
const Timetable = sequelize.define(
  "Timetable",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    teacherId: { type: DataTypes.INTEGER, allowNull: false },
    subjectId: { type: DataTypes.INTEGER, allowNull: false },
    day: { type: DataTypes.STRING(20), allowNull: false },
    startTime: { type: DataTypes.TIME, allowNull: false },
    endTime: { type: DataTypes.TIME, allowNull: false },
    location: { type: DataTypes.STRING(150), allowNull: true },
    color: { type: DataTypes.STRING(7), allowNull: false, defaultValue: "#dbeafe" },
    term: { type: DataTypes.STRING(20), allowNull: false },
    academicYear: { type: DataTypes.STRING(9), allowNull: false },
  },
  { tableName: "timetables", timestamps: true },
);

const SubstituteRequest = sequelize.define(
  "SubstituteRequest",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    timetableId: { type: DataTypes.INTEGER, allowNull: false },
    requesterTeacherId: { type: DataTypes.INTEGER, allowNull: false },
    substituteTeacherId: { type: DataTypes.INTEGER, allowNull: false },
    status: {
      type: DataTypes.ENUM("pending", "accepted", "declined"),
      allowNull: false,
      defaultValue: "pending",
    },
    note: { type: DataTypes.TEXT, allowNull: true },
  },
  { tableName: "substitute_requests", timestamps: true },
);

// ─── Lesson Plans ─────────────────────────────────────────────────────────────
const LessonPlan = sequelize.define(
  "LessonPlan",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    teacherId: { type: DataTypes.INTEGER, allowNull: false },
    createdByTeacherId: { type: DataTypes.INTEGER, allowNull: true },
    classId: { type: DataTypes.INTEGER, allowNull: false },
    subjectId: { type: DataTypes.INTEGER, allowNull: false },
    periodType: { type: DataTypes.ENUM("day", "week", "term"), allowNull: false },
    startDate: { type: DataTypes.DATEONLY, allowNull: false },
    endDate: { type: DataTypes.DATEONLY, allowNull: false },
    term: { type: DataTypes.STRING(30), allowNull: true },
    academicYear: { type: DataTypes.STRING(20), allowNull: true },
    topic: { type: DataTypes.STRING(255), allowNull: false },
    subtitle: { type: DataTypes.STRING(255), allowNull: true },
    mainCompetence: { type: DataTypes.TEXT, allowNull: true },
    keyConcepts: { type: DataTypes.TEXT, allowNull: true },
    specificCompetence: { type: DataTypes.TEXT, allowNull: true },
    essentialQuestions: { type: DataTypes.TEXT, allowNull: true },
    formativeAssessment: { type: DataTypes.TEXT, allowNull: true },
    summativeAssessment: { type: DataTypes.TEXT, allowNull: true },
    lessonSteps: { type: DataTypes.TEXT, allowNull: true },
    materials: { type: DataTypes.TEXT, allowNull: true },
    assignment: { type: DataTypes.TEXT, allowNull: true },
    differentiationStrategies: { type: DataTypes.TEXT, allowNull: true },
    instructionalStrategies: { type: DataTypes.TEXT, allowNull: true },
    objectiveTags: { type: DataTypes.TEXT, allowNull: true },
    status: {
      type: DataTypes.ENUM("pending", "approved", "returned"),
      allowNull: false,
      defaultValue: "pending",
    },
  },
  { tableName: "lesson_plans", timestamps: true },
);

const LessonPlanFeedback = sequelize.define(
  "LessonPlanFeedback",
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    lessonPlanId: { type: DataTypes.INTEGER, allowNull: false },
    authorName: { type: DataTypes.STRING(100), allowNull: false },
    authorRole: { type: DataTypes.STRING(30), allowNull: false },
    comment: { type: DataTypes.TEXT, allowNull: false },
  },
  { tableName: "lesson_plan_feedback", timestamps: true },
);

// ─── Associations ─────────────────────────────────────────────────────────────
AcademicYear.hasMany(Term, { foreignKey: "academicYearId", as: "terms" });
Term.belongsTo(AcademicYear, {
  foreignKey: "academicYearId",
  as: "academicYear",
});

Department.hasMany(Teacher, { foreignKey: "departmentId", as: "teachers" });
Teacher.belongsTo(Department, { foreignKey: "departmentId", as: "department" });

Department.hasMany(Class, { foreignKey: "departmentId", as: "classes" });
Class.belongsTo(Department, { foreignKey: "departmentId", as: "department" });

Class.hasMany(Stream, { foreignKey: "classId", as: "streams" });
Stream.belongsTo(Class, { foreignKey: "classId", as: "class" });

Class.hasMany(Subject, { foreignKey: "classId", as: "subjects" });
Subject.belongsTo(Class, { foreignKey: "classId", as: "class" });

Class.hasMany(Student, { foreignKey: "classId", as: "students" });
Student.belongsTo(Class, { foreignKey: "classId", as: "class" });

Stream.hasMany(Student, { foreignKey: "streamId", as: "students" });
Student.belongsTo(Stream, { foreignKey: "streamId", as: "stream" });

Teacher.belongsToMany(Class, {
  through: TeacherClass,
  foreignKey: "teacherId",
  as: "classes",
});
Class.belongsToMany(Teacher, {
  through: TeacherClass,
  foreignKey: "classId",
  as: "teachers",
});

Subject.belongsToMany(Class, {
  through: ClassSubject,
  foreignKey: "subjectId",
  as: "assignedClasses",
});
Class.belongsToMany(Subject, {
  through: ClassSubject,
  foreignKey: "classId",
  as: "assignedSubjects",
});

Teacher.belongsToMany(Subject, {
  through: TeacherSubject,
  foreignKey: "teacherId",
  as: "subjects",
});
Subject.belongsToMany(Teacher, {
  through: TeacherSubject,
  foreignKey: "subjectId",
  as: "teachers",
});

ReportComment.belongsTo(Student, { foreignKey: "studentId", as: "student" });
ReportComment.belongsTo(Class, { foreignKey: "classId", as: "class" });
ReportComment.belongsTo(Teacher, { foreignKey: "teacherId", as: "teacher" });
Student.hasMany(ReportComment, { foreignKey: "studentId", as: "comments" });

// Join table belongsTo (needed for include in list views)
TeacherClass.belongsTo(Teacher, { foreignKey: "teacherId", as: "teacher" });
TeacherClass.belongsTo(Class, { foreignKey: "classId", as: "class" });
TeacherClass.belongsTo(Stream, { foreignKey: "streamId", as: "stream" });

TeacherSubject.belongsTo(Teacher, { foreignKey: "teacherId", as: "teacher" });
TeacherSubject.belongsTo(Subject, { foreignKey: "subjectId", as: "subject" });
TeacherSubject.belongsTo(Class, { foreignKey: "classId", as: "class" });

ClassSubject.belongsTo(Class, { foreignKey: "classId", as: "class" });
ClassSubject.belongsTo(Subject, { foreignKey: "subjectId", as: "subject" });

Student.hasMany(Attendance, { foreignKey: "studentId", as: "attendances" });
Attendance.belongsTo(Student, { foreignKey: "studentId", as: "student" });
Attendance.belongsTo(Class, { foreignKey: "classId", as: "class" });
// Attendance may be entered by either a teacher or an administrator account.
Attendance.belongsTo(Teacher, {
  foreignKey: "takenBy",
  as: "teacher",
  constraints: false,
});

Student.hasMany(Mark, { foreignKey: "studentId", as: "marks" });
Mark.belongsTo(Student, { foreignKey: "studentId", as: "student" });
Mark.belongsTo(Subject, { foreignKey: "subjectId", as: "subject" });
Mark.belongsTo(Class, { foreignKey: "classId", as: "class" });
// Marks may be entered by either a teacher or an administrator account.
Mark.belongsTo(Teacher, {
  foreignKey: "enteredBy",
  as: "teacher",
  constraints: false,
});

// Timetable associations
Teacher.hasMany(Timetable, { foreignKey: "teacherId", as: "timetables" });
Timetable.belongsTo(Teacher, { foreignKey: "teacherId", as: "teacher" });
// Link timetable -> subject
Timetable.belongsTo(Subject, { foreignKey: "subjectId", as: "subject" });
Subject.hasMany(Timetable, { foreignKey: "subjectId", as: "timetables" });
Timetable.hasMany(SubstituteRequest, { foreignKey: "timetableId", as: "substituteRequests" });
SubstituteRequest.belongsTo(Timetable, { foreignKey: "timetableId", as: "timetable" });
SubstituteRequest.belongsTo(Teacher, { foreignKey: "requesterTeacherId", as: "requester" });
SubstituteRequest.belongsTo(Teacher, { foreignKey: "substituteTeacherId", as: "substitute" });

Teacher.hasMany(LessonPlan, { foreignKey: "teacherId", as: "lessonPlans" });
LessonPlan.belongsTo(Teacher, { foreignKey: "teacherId", as: "teacher" });
LessonPlan.belongsTo(Teacher, { foreignKey: "createdByTeacherId", as: "createdBy" });
LessonPlan.belongsTo(Class, { foreignKey: "classId", as: "class" });
LessonPlan.belongsTo(Subject, { foreignKey: "subjectId", as: "subject" });
LessonPlan.hasMany(LessonPlanFeedback, { foreignKey: "lessonPlanId", as: "feedback" });
LessonPlanFeedback.belongsTo(LessonPlan, { foreignKey: "lessonPlanId", as: "lessonPlan" });

module.exports = {
  sequelize,
  AcademicYear,
  Term,
  Department,
  Teacher,
  Admin,
  Class,
  Stream,
  Subject,
  Student,
  ReportComment,
  TeacherClass,
  TeacherSubject,
  ClassSubject,
  PublicHoliday,
  Attendance,
  Mark,
  Timetable,
  SubstituteRequest,
  LessonPlan,
  LessonPlanFeedback,
};
