const bcrypt = require('bcryptjs');
const { sequelize, Admin, PublicHoliday, Department } = require('../models');

async function seed() {
  try {
    await sequelize.sync({ force: false });
    console.log('✅ Database synced');

    // Create default admin
    const adminExists = await Admin.findOne({ where: { username: 'sys_administrator' } });
    if (!adminExists) {
      const hash = await bcrypt.hash('Tufail@1710..@', 10);
      await Admin.create({ username: 'sys_administrator', password: hash, email: 'kallagiga@gmail.com' });
    //   console.log('✅ Default admin created (sys_administrator / Tufail@1710..@)');
    }

    console.log(' Seeding complete!');
    process.exit(0);
  } catch (err) {
    console.error(' Seed error:', err);
    process.exit(1);
  }
}

seed();
