const bcrypt = require('bcryptjs');
const { sequelize, Admin, PublicHoliday, Department } = require('../models');

async function seed() {
  try {
    await sequelize.sync({ force: false });
    console.log('✅ Database synced');

    // Seed Tanzania public holidays 2026-2027
    const holidays = [
      { name: "New Year's Day", date: '2026-01-01' },
      { name: 'Zanzibar Revolution Day', date: '2026-01-12' },
      { name: 'CCM Foundation Day', date: '2026-02-05' },
      { name: 'International Women\'s Day', date: '2026-03-08' },
      { name: 'Good Friday', date: '2026-04-18' },
      { name: 'Easter Saturday', date: '2026-04-19' },
      { name: 'Easter Monday', date: '2026-04-21' },
      { name: 'Union Day', date: '2026-04-26' },
      { name: 'Workers Day', date: '2026-05-01' },
      { name: 'Eid al-Fitr', date: '2026-03-30' },
      { name: 'Eid al-Adha', date: '2026-06-06' },
      { name: 'Saba Saba Day', date: '2026-07-07' },
      { name: 'Peasants Day', date: '2026-08-08' },
      { name: 'Mwalimu Nyerere Day', date: '2026-10-14' },
      { name: 'Independence Day', date: '2026-12-09' },
      { name: 'Christmas Day', date: '2026-12-25' },
      { name: 'Boxing Day', date: '2026-12-26' },
      { name: "New Year's Day", date: '2027-01-01' }
    ];

    for (const h of holidays) {
      await PublicHoliday.findOrCreate({ where: { date: h.date }, defaults: h });
    }
    console.log('✅ Public holidays seeded');

    console.log(' Seeding complete!');
    process.exit(0);
  } catch (err) {
    console.error(' Seed error:', err);
    process.exit(1);
  }
}

seed();
